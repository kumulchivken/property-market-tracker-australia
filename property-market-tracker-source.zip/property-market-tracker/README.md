# Australian Property & Market Cycle Tracker

An authenticated dashboard for dated property-value snapshots, official national macro indicators, and transparent market-cycle notes. The source code is public; portfolio records remain private in the authenticated backend.

## What it does

- Saves properties, dated value history, macro observations, and manual cycle notes in per-user D1 records.
- Asks whether you want to add properties before each manual refresh.
- Uses user-entered valuations by default; no portal scraping or invented address-level estimates.
- Shows nominal and CPI-adjusted indexed property history once at least two snapshots and CPI observations exist.
- Retrieves CPI and unemployment from the ABS Data API and cash-rate history from the RBA Cash Rate Target page.
- Shows an “Insufficient data” regional clock unless you add a dated, evidenced manual phase override.
- Supports add/edit/archive/restore and JSON export. Archive preserves history.

## Privacy

The current Site is owner-only. The Worker requires the Sites authenticated-user identity header for every API call and scopes every database query to that identity. Full addresses and valuations do not appear in URLs, analytics, sample fixtures, or client logs. Transport is HTTPS. The public repository contains source only; do not commit portfolio exports, addresses, values, or credentials. No property provider credentials are configured.

## Use

1. Open the owner-only Site while signed into the account that owns it.
2. Add a property and its location details.
3. Use **Add value** to enter a dated snapshot and record its source.
4. Choose a property in **Value history**; two or more dated values are required for a chart.
5. Use **Run now** to refresh the official macro feeds. The prompt asks whether to add properties first. Address-level values are not automatically refreshed.
6. Export your own data from **Export data**.
7. Use **Set manual phase** only when you have local evidence to cite. This stays visibly marked as a manual override.

## Refresh behavior and data limits

The ABS CPI Data API and Labour Force series have publication delays. Their observation period is not necessarily the release date; the UI displays the recorded period and release date separately. If an official feed fails or changes structure, the refresh reports the issue and leaves prior observations intact. No periodic schedule is enabled. Automatic refresh should only be configured with an unattended identity and a cadence you choose.

## Sources

- ABS Data API: https://data.api.abs.gov.au/rest/
- ABS CPI: https://www.abs.gov.au/statistics/economy/price-indexes-and-inflation/consumer-price-index-australia
- ABS Labour Force: https://www.abs.gov.au/statistics/labour/employment-and-unemployment/labour-force-australia
- RBA Cash Rate Target: https://www.rba.gov.au/statistics/cash-rate/

## Build and deploy

Requires Node.js 20+. Run `node scripts/build.mjs`; the build outputs `dist/server/index.js`, Site hosting metadata, and the D1 schema migration. The current app needs a Worker, D1, and the authenticated-user identity supplied by its hosting platform. GitHub Pages serves static files only and will not provide the `/api` routes or authentication this dashboard requires. Do not make the personal dashboard public by disabling authentication. A public-facing website must use a separate, public-safe view that cannot access personal portfolio records.

## Public source and public deployment

The repository is public at the owner's request. This does not make the existing owner-only Site public. The private portfolio backend must remain access-controlled. Public hosting of the current app has not been configured; the Sites source host was unavailable when deployment was attempted. Before publishing a public-facing version, provide a separate public-safe mode and test that it cannot read or write personal portfolio data.

## Licensed property-data adapter

No valuation feed is configured. Add any licensed provider only after establishing its contract and API; credentials must be stored as hosting secrets, never committed or exposed in the browser bundle.
